# Logic for embedding, vector search, and LLM response
