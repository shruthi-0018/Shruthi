from fastapi import FastAPI
from pydantic import BaseModel
from rag_engine import get_answer

app = FastAPI()

class Question(BaseModel):
    question: str

@app.post("/ask")
def ask(question: Question):
    response = get_answer(question.question)
    return response
