# Web-Based RAG Tool using Product Catalog

This project is a proof-of-concept Retrieval-Augmented Generation (RAG) tool. Users can ask natural questions about products and get answers generated using a combination of vector search and large language models.

## Features
- Embeds and indexes product catalog
- Accepts user queries via API or frontend
- Retrieves relevant product chunks
- Generates natural language answers using GPT
- Shows source products for transparency

## Tech Stack
- Backend: Python, FastAPI, FAISS
- Embeddings: OpenAI / HuggingFace
- LLM: OpenAI GPT-3.5/4 (or plug-in local model)
- Frontend: React or Streamlit

## Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Run backend
uvicorn backend.main:app --reload
```

## API
POST `/ask`
```json
{
  "question": "What are the best headphones under $100?"
}
```

## Coming soon
- Frontend UI
- Filter by category/price
- Docker deployment
